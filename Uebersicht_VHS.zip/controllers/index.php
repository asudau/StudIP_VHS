<?php
//require_once 'lib/classes/DBManager.class.php';


class IndexController extends StudipController {

    public function __construct($dispatcher)
    {
        parent::__construct($dispatcher);
        $this->plugin = $dispatcher->plugin;
        Navigation::activateItem('course/overviewvhs');
    }

    public function before_filter(&$action, &$args)
    {
        parent::before_filter($action, $args);

        $this->course          = Course::findCurrent();

        PageLayout::setTitle($this->course->getFullname()." - " ._("�bersicht"));

        // $this->set_layout('layouts/base');
        $this->set_layout($GLOBALS['template_factory']->open('layouts/base'));
    }

    public function index_action()
    {
        
        
        $actions = new ActionsWidget();
        $actions->setTitle(_('Aktionen'));

        $actions->addLink(
        'Einstellungen',
        PluginEngine::GetURL('TNActivity/index/settings'),'icons/16/blue/add.png'); 

        Sidebar::get()->addWidget($actions);
        

    }
    
    // customized #url_for for plugins
    public function url_for($to)
    {
        $args = func_get_args();

        # find params
        $params = array();
        if (is_array(end($args))) {
            $params = array_pop($args);
        }

        # urlencode all but the first argument
        $args = array_map('urlencode', $args);
        $args[0] = $to;

        return PluginEngine::getURL($this->dispatcher->plugin, $params, join('/', $args));
    }
}
